package com.axiom.client.module.modules.misc;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class AntiCheat extends Module {

    private double  lastX, lastY, lastZ;
    private boolean lastOnGround;
    private int     staticTicks        = 0;
    private int     groundDesyncTicks  = 0;

    public AntiCheat() {
        super("AntiCheat", Category.MISC);
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient mc) {
        if (!isEnabled() || mc.player == null) return;

        double x = mc.player.getX();
        double y = mc.player.getY();
        double z = mc.player.getZ();

        if (x == lastX && z == lastZ) {
            staticTicks++;
            if (staticTicks > 20) {
                mc.player.setPos(
                    x + (Math.random() * 0.0001 - 0.00005),
                    y,
                    z + (Math.random() * 0.0001 - 0.00005)
                );
                staticTicks = 0;
            }
        } else {
            staticTicks = 0;
        }

        boolean onGround = mc.player.isOnGround();
        if (onGround != lastOnGround) {
            groundDesyncTicks++;
            if (groundDesyncTicks > 2) {
                mc.getNetworkHandler().sendPacket(
                    new PlayerMoveC2SPacket.OnGroundOnly(onGround)
                );
                groundDesyncTicks = 0;
            }
        } else {
            groundDesyncTicks = 0;
        }

        lastX = x; lastY = y; lastZ = z;
        lastOnGround = onGround;
    }
}
