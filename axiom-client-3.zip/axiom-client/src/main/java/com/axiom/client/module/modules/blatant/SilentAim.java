package com.axiom.client.module.modules.blatant;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

import java.util.Comparator;
import java.util.List;

public class SilentAim extends Module {

    private static final float RANGE = 6.0f;
    private float realYaw;
    private float realPitch;

    public SilentAim() {
        super("SilentAim", Category.BLATANT);
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient mc) {
        if (!isEnabled()) return;
        if (mc.player == null || mc.world == null) return;

        realYaw   = mc.player.getYaw();
        realPitch = mc.player.getPitch();

        PlayerEntity target = getNearestPlayer(mc);
        if (target == null) return;

        float[] rot   = calculateRotations(mc, target);
        float silentYaw   = rot[0];
        float silentPitch = rot[1];

        mc.player.setYaw(silentYaw);
        mc.player.setPitch(silentPitch);

        mc.getNetworkHandler().sendPacket(
            new PlayerMoveC2SPacket.LookAndOnGround(silentYaw, silentPitch, mc.player.isOnGround())
        );

        mc.player.setYaw(realYaw);
        mc.player.setPitch(realPitch);
        mc.player.prevYaw   = realYaw;
        mc.player.prevPitch = realPitch;
    }

    private PlayerEntity getNearestPlayer(MinecraftClient mc) {
        List<PlayerEntity> players = mc.world.getEntitiesByClass(
                PlayerEntity.class,
                mc.player.getBoundingBox().expand(RANGE),
                e -> e != mc.player && !e.isSpectator() && e.isAlive() && !e.isInvisible()
        );
        return players.stream()
                .min(Comparator.comparingDouble(e -> e.squaredDistanceTo(mc.player)))
                .orElse(null);
    }

    private float[] calculateRotations(MinecraftClient mc, PlayerEntity target) {
        double dx = target.getX() - mc.player.getX();
        double dy = (target.getY() + target.getHeight() * 0.9f)
                  - (mc.player.getY() + mc.player.getStandingEyeHeight());
        double dz = target.getZ() - mc.player.getZ();
        double dist  = Math.sqrt(dx * dx + dz * dz);
        float  yaw   = (float)(Math.toDegrees(Math.atan2(dz, dx))) - 90.0f;
        float  pitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));
        pitch = Math.max(-90.0f, Math.min(90.0f, pitch));
        return new float[]{ yaw, pitch };
    }

    public float getRealYaw()   { return realYaw; }
    public float getRealPitch() { return realPitch; }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        mc.player.setYaw(realYaw);
        mc.player.setPitch(realPitch);
        mc.player.prevYaw   = realYaw;
        mc.player.prevPitch = realPitch;
    }
}
