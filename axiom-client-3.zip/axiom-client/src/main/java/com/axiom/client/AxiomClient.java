package com.axiom.client;

import com.axiom.client.gui.ClickGUI;
import com.axiom.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class AxiomClient implements ClientModInitializer {

    private static AxiomClient INSTANCE;
    private ModuleManager moduleManager;
    private KeyBinding guiKey;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        moduleManager = new ModuleManager();

        guiKey = new KeyBinding(
                "key.axiom.gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.axiom"
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (guiKey.wasPressed()) {
                if (client.currentScreen instanceof ClickGUI) {
                    client.setScreen(null);
                } else {
                    client.setScreen(new ClickGUI());
                }
            }
            moduleManager.onTick();
        });
    }

    public static AxiomClient getInstance() { return INSTANCE; }
    public ModuleManager getModuleManager() { return moduleManager; }
}
