package com.axiom.client.module.modules.combat;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;

import java.util.Comparator;
import java.util.List;

public class AutoMace extends Module {

    private static final float  RANGE         = 5.5f;
    private static final int    WIND_UP_TICKS = 12;
    private static final double MIN_FALL_VEL  = -0.25;

    private enum State {
        IDLE, SWAPPING_TO_MACE, ROTATING, JUMPING,
        WINDING, RELEASING, SWAPPING_BACK
    }

    private State        state        = State.IDLE;
    private int          stateTick    = 0;
    private int          previousSlot = -1;
    private int          maceSlot     = -1;
    private float        realYaw;
    private float        realPitch;
    private PlayerEntity target;

    public AutoMace() {
        super("AutoMace", Category.COMBAT);
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient mc) {
        if (!isEnabled()) return;
        if (mc.player == null || mc.world == null) return;

        stateTick++;

        switch (state) {

            case IDLE -> {
                target   = getNearestPlayer(mc);
                maceSlot = findMaceSlot(mc);

                if (target == null || maceSlot == -1) return;
                if (mc.player.getAttackCooldownProgress(0f) < 1.0f) return;

                realYaw      = mc.player.getYaw();
                realPitch    = mc.player.getPitch();
                previousSlot = mc.player.getInventory().selectedSlot;

                state     = State.SWAPPING_TO_MACE;
                stateTick = 0;
            }

            case SWAPPING_TO_MACE -> {
                swapToSlot(mc, maceSlot);
                state     = State.ROTATING;
                stateTick = 0;
            }

            case ROTATING -> {
                if (!targetValid()) { reset(mc); return; }
                float[] rot = calcRotations(mc, target);
                sendSilentLook(mc, rot[0], rot[1]);
                if (stateTick >= 1) {
                    mc.player.jump();
                    state     = State.JUMPING;
                    stateTick = 0;
                }
            }

            case JUMPING -> {
                if (!targetValid()) { reset(mc); return; }
                float[] rot = calcRotations(mc, target);
                sendSilentLook(mc, rot[0], rot[1]);
                if (!mc.player.isOnGround() && mc.player.getVelocity().y > 0) {
                    state     = State.WINDING;
                    stateTick = 0;
                }
            }

            case WINDING -> {
                if (!targetValid()) { reset(mc); return; }
                float[] rot = calcRotations(mc, target);
                sendSilentLook(mc, rot[0], rot[1]);
                mc.options.attackKey.setPressed(true);
                boolean descended = mc.player.getVelocity().y <= MIN_FALL_VEL;
                if (stateTick >= WIND_UP_TICKS && descended) {
                    state     = State.RELEASING;
                    stateTick = 0;
                }
            }

            case RELEASING -> {
                float[] rot = calcRotations(mc, target);
                sendSilentLook(mc, rot[0], rot[1]);
                mc.options.attackKey.setPressed(false);
                if (target != null) {
                    mc.interactionManager.attackEntity(mc.player, target);
                    mc.player.swingHand(Hand.MAIN_HAND);
                }
                restoreRotations(mc);
                state     = State.SWAPPING_BACK;
                stateTick = 0;
            }

            case SWAPPING_BACK -> {
                if (stateTick < 2) return;
                if (previousSlot != -1 && previousSlot != maceSlot) {
                    swapToSlot(mc, previousSlot);
                }
                state     = State.IDLE;
                stateTick = 0;
                target    = null;
            }
        }
    }

    private void swapToSlot(MinecraftClient mc, int slot) {
        mc.player.getInventory().selectedSlot = slot;
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }

    private int findMaceSlot(MinecraftClient mc) {
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(Items.MACE)) return i;
        }
        return -1;
    }

    private float[] calcRotations(MinecraftClient mc, PlayerEntity t) {
        double dx = t.getX() - mc.player.getX();
        double dy = (t.getY() + t.getHeight() * 0.9f)
                  - (mc.player.getY() + mc.player.getStandingEyeHeight());
        double dz = t.getZ() - mc.player.getZ();
        double dist  = Math.sqrt(dx * dx + dz * dz);
        float  yaw   = (float)(Math.toDegrees(Math.atan2(dz, dx))) - 90.0f;
        float  pitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));
        pitch = Math.max(-90.0f, Math.min(90.0f, pitch));
        return new float[]{ yaw, pitch };
    }

    private void sendSilentLook(MinecraftClient mc, float yaw, float pitch) {
        mc.getNetworkHandler().sendPacket(
            new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, mc.player.isOnGround())
        );
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);
        mc.player.setYaw(realYaw);
        mc.player.setPitch(realPitch);
        mc.player.prevYaw   = realYaw;
        mc.player.prevPitch = realPitch;
    }

    private void restoreRotations(MinecraftClient mc) {
        if (mc.player == null) return;
        mc.player.setYaw(realYaw);
        mc.player.setPitch(realPitch);
        mc.player.prevYaw   = realYaw;
        mc.player.prevPitch = realPitch;
    }

    private PlayerEntity getNearestPlayer(MinecraftClient mc) {
        List<PlayerEntity> targets = mc.world.getEntitiesByClass(
                PlayerEntity.class,
                mc.player.getBoundingBox().expand(RANGE),
                e -> e != mc.player && !e.isSpectator() && e.isAlive() && !e.isInvisible()
        );
        return targets.stream()
                .min(Comparator.comparingDouble(e -> e.squaredDistanceTo(mc.player)))
                .orElse(null);
    }

    private boolean targetValid() {
        return target != null && target.isAlive() && !target.isRemoved();
    }

    private void reset(MinecraftClient mc) {
        mc.options.attackKey.setPressed(false);
        restoreRotations(mc);
        if (previousSlot != -1 && previousSlot != maceSlot
                && mc.player != null
                && mc.player.getInventory().selectedSlot == maceSlot) {
            swapToSlot(mc, previousSlot);
        }
        state = State.IDLE; stateTick = 0;
        target = null; previousSlot = -1; maceSlot = -1;
    }

    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) reset(mc);
    }
}
