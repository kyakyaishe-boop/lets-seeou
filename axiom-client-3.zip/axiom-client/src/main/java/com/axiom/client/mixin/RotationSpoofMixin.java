package com.axiom.client.mixin;

import com.axiom.client.AxiomClient;
import com.axiom.client.module.modules.blatant.SilentAim;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class RotationSpoofMixin {

    @Inject(method = "sendPacket(Lnet/minecraft/network/packet/Packet;)V",
            at = @At("HEAD"))
    private void spoofRotation(net.minecraft.network.packet.Packet<?> packet, CallbackInfo ci) {
        if (!(packet instanceof PlayerMoveC2SPacket move)) return;
        if (!move.changesLook()) return;

        SilentAim sa = (SilentAim) AxiomClient.getInstance()
                .getModuleManager().getByName("SilentAim");
        if (sa == null || !sa.isEnabled()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        try {
            var yawField = PlayerMoveC2SPacket.class.getDeclaredField("yaw");
            var pitchField = PlayerMoveC2SPacket.class.getDeclaredField("pitch");
            yawField.setAccessible(true);
            pitchField.setAccessible(true);
            yawField.set(move, sa.getRealYaw());
            pitchField.set(move, sa.getRealPitch());
        } catch (Exception ignored) {}
    }
}
