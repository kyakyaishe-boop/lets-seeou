package com.axiom.client.mixin;

import com.axiom.client.AxiomClient;
import com.axiom.client.module.modules.combat.Reach;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public class ReachMixin {

    @Inject(method = "getReachDistance", at = @At("RETURN"), cancellable = true)
    private void extendReach(CallbackInfoReturnable<Float> cir) {
        Reach reach = (Reach) AxiomClient.getInstance()
                .getModuleManager().getByName("Reach");
        if (reach != null && reach.isEnabled()) {
            cir.setReturnValue((float) Reach.REACH_DISTANCE);
        }
    }
}
