package com.axiom.client.mixin;

import com.axiom.client.AxiomClient;
import com.axiom.client.module.modules.misc.NoFall;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class NoFallSpoofMixin {

    @Inject(method = "sendPacket(Lnet/minecraft/network/packet/Packet;)V",
            at = @At("HEAD"))
    private void spoofGroundOnFall(net.minecraft.network.packet.Packet<?> packet, CallbackInfo ci) {
        if (!(packet instanceof PlayerMoveC2SPacket move)) return;

        NoFall nf = (NoFall) AxiomClient.getInstance()
                .getModuleManager().getByName("NoFall");
        if (nf == null || !nf.isEnabled()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        if (mc.player.getVelocity().y < -0.5 && !mc.player.isOnGround()) {
            try {
                var field = PlayerMoveC2SPacket.class.getDeclaredField("onGround");
                field.setAccessible(true);
                field.set(move, true);
            } catch (Exception ignored) {}
        }
    }
}
