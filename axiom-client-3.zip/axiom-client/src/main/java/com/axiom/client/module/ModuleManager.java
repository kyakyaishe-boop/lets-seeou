package com.axiom.client.module;

import com.axiom.client.module.modules.blatant.SilentAim;
import com.axiom.client.module.modules.combat.AutoMace;
import com.axiom.client.module.modules.combat.Reach;
import com.axiom.client.module.modules.combat.Triggerbot;
import com.axiom.client.module.modules.combat.Velocity;
import com.axiom.client.module.modules.misc.AntiAFK;
import com.axiom.client.module.modules.misc.AntiCheat;
import com.axiom.client.module.modules.misc.ChatSpam;
import com.axiom.client.module.modules.misc.FastPlace;
import com.axiom.client.module.modules.misc.Freecam;
import com.axiom.client.module.modules.misc.NoFall;
import com.axiom.client.module.modules.misc.NoRotate;
import com.axiom.client.module.modules.misc.NoSlow;
import com.axiom.client.module.modules.misc.Sprint;
import com.axiom.client.module.modules.visuals.ESP;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // Combat
        modules.add(new AutoMace());
        modules.add(new Triggerbot());
        modules.add(new Reach());
        modules.add(new Velocity());

        // Visuals
        modules.add(new ESP());

        // Misc
        modules.add(new Sprint());
        modules.add(new NoFall());
        modules.add(new FastPlace());
        modules.add(new NoSlow());
        modules.add(new AntiAFK());
        modules.add(new Freecam());
        modules.add(new NoRotate());
        modules.add(new ChatSpam());
        modules.add(new AntiCheat());

        // Blatant
        modules.add(new SilentAim());
    }

    public List<Module> getModules() { return modules; }

    public List<Module> getByCategory(Category category) {
        return modules.stream()
                .filter(m -> m.getCategory() == category)
                .collect(Collectors.toList());
    }

    public Module getByName(String name) {
        return modules.stream()
                .filter(m -> m.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    public void onTick() {
        modules.stream().filter(Module::isEnabled).forEach(Module::onTick);
    }
}
