package com.axiom.client.module.modules.misc;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;

public class NoFall extends Module {

    public NoFall() {
        super("NoFall", Category.MISC);
    }
}
